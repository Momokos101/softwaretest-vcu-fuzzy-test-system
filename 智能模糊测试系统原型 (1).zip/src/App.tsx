import { useState } from "react";
import { Dashboard } from "./components/Dashboard";
import { TestMonitoring } from "./components/TestMonitoring";
import { TestManagement } from "./components/TestManagement";
import { ResultAnalysis } from "./components/ResultAnalysis";
import { ReportCenter } from "./components/ReportCenter";
import { SystemSettings } from "./components/SystemSettings";
import { TopNav } from "./components/TopNav";
import { Sidebar } from "./components/Sidebar";

export default function App() {
  const [currentView, setCurrentView] = useState<
    | "dashboard"
    | "tests"
    | "analysis"
    | "reports"
    | "settings"
    | "monitoring"
  >("dashboard");

  const renderView = () => {
    switch (currentView) {
      case "dashboard":
        return (
          <Dashboard
            onCreateTest={() => setCurrentView("tests")}
            onViewMonitoring={() =>
              setCurrentView("monitoring")
            }
          />
        );
      case "tests":
        return (
          <TestManagement
            onCreateTest={() => setCurrentView("tests")}
            onViewMonitoring={() =>
              setCurrentView("monitoring")
            }
          />
        );
      case "analysis":
        return <ResultAnalysis />;
      case "reports":
        return <ReportCenter />;
      case "settings":
        return <SystemSettings />;
      case "monitoring":
        return (
          <TestMonitoring
            onBack={() => setCurrentView("dashboard")}
          />
        );
      default:
        return (
          <Dashboard
            onCreateTest={() => setCurrentView("tests")}
            onViewMonitoring={() =>
              setCurrentView("monitoring")
            }
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-slate-50/30">
      <TopNav />
      <div className="flex">
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
        />
        <main className="flex-1 ml-[240px]">
          {renderView()}
        </main>
      </div>
    </div>
  );
}