
  # 智能模糊测试系统原型

  This is a code bundle for 智能模糊测试系统原型. The original project is available at https://www.figma.com/design/f9vku4YQRhTBf88TKDAu23/%E6%99%BA%E8%83%BD%E6%A8%A1%E7%B3%8A%E6%B5%8B%E8%AF%95%E7%B3%BB%E7%BB%9F%E5%8E%9F%E5%9E%8B.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  