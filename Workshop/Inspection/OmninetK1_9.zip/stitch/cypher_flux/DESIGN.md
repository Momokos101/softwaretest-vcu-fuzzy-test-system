# Design System Specification: High-Tech Intelligence

## 1. Overview & Creative North Star
**Creative North Star: The Sentinel Core**
This design system rejects the "SaaS-template" aesthetic in favor of a bespoke, editorial digital environment. It is modeled after high-end intelligence consoles—sophisticated, fast, and secure. We achieve this through "The Sentinel Core" philosophy: a visual language where data feels alive, protected by layers of translucent glass and deep tonal depth. 

Instead of rigid grids and borders, we utilize **Intentional Asymmetry** and **Tonal Topography**. Elements do not just sit on a page; they occupy a 3D coordinate space. High-contrast typography scales and vibrant neon accents act as "beacons" for the user’s eye, ensuring that speed is never sacrificed for sophistication.

---

## 2. Colors & Surface Architecture
The palette is rooted in a deep, nocturnal base (`#0d0e13`) punctuated by electric, high-frequency interactive tokens.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid strokes for sectioning or layout containment. Boundaries must be defined solely through background shifts. For example, a `surface_container_low` sidebar sitting against a `background` main stage creates a natural, sophisticated break without visual clutter.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of tinted crystalline glass. 
- **Layer 0 (Base):** `background` (#0d0e13) - The infinite void.
- **Layer 1 (Main UI):** `surface_container_low` (#121319) - Used for primary content regions.
- **Layer 2 (Interactive Elements):** `surface_container_high` (#1e1f26) - Used for cards and navigation headers.
- **Layer 3 (Floating Overlays):** `surface_bright` (#2a2c34) - Reserved for high-importance modals.

### The "Glass & Gradient" Rule
To elevate the "tech" feel, all floating elements (modals, dropdowns) must use a **Glassmorphism** effect. Apply `surface_container_highest` at 70% opacity with a `20px` backdrop-blur. 
- **Signature Textures:** For primary CTAs, use a linear gradient (135°) from `primary` (#81ecff) to `primary_container` (#00e3fd) to provide a "pulsing" energy that flat colors lack.

---

## 3. Typography
We utilize a dual-font strategy to balance high-tech precision with human-centric readability.

*   **Display & Headlines:** **Space Grotesk.** This font conveys structural intelligence. Use `display-lg` (3.5rem) with tighter letter-spacing (-0.02em) for hero moments to create an authoritative, editorial impact.
*   **Body & Utility:** **Inter.** Chosen for its mathematical clarity. `body-md` (0.875rem) serves as the workhorse for all data-heavy views.

**Hierarchy as Identity:** 
- Use `label-md` (Inter, 0.75rem) in uppercase with 0.1rem tracking for all "system-status" text to mimic terminal outputs.
- Boldly contrast `headline-lg` (Space Grotesk) against `body-sm` (Inter) to create a clear informational scent-trail for the user.

---

## 4. Elevation & Depth
Depth in this system is a product of light and layering, never "structural" lines.

### The Layering Principle
Achieve lift by "stacking" the surface-container tiers. Place a `surface_container_lowest` input field inside a `surface_container_low` card. This creates a soft "recessed" look that feels integrated into the architecture.

### Ambient Shadows
Shadows must be invisible but felt. 
- **Token:** `0px 24px 48px rgba(0, 0, 0, 0.5)`. 
- Shadows should be tinted with a hint of the `primary` color (at 2-4% opacity) to mimic the glow of a high-tech screen in a dark room.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., focus states), use a **Ghost Border**: `outline_variant` (#47474e) at **20% opacity**. Never use 100% opaque borders.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on_primary` text. Border-radius: `md` (0.375rem).
- **Secondary:** Transparent background with a `ghost border`. 
- **States:** On hover, primary buttons should have a `primary_dim` outer glow (4px spread).

### Cards & Lists
- **Rule:** Forbid divider lines. 
- Use vertical white space (`spacing-8` or `spacing-10`) to separate items. For lists, alternate backgrounds between `surface_container` and `surface_container_low` to create a "zebra" effect that is felt rather than seen.

### Input Fields
- **Base:** `surface_container_lowest` (#000000).
- **Focus State:** A 1px `ghost border` using `primary` at 40% opacity and a `primary_fixed` bottom-weighted glow.
- **Error:** Utilize `error` (#ff716c) only for the label and a subtle 2px left-accent bar; do not outline the whole box.

### Chips (Data Tags)
- Use `secondary_container` with `on_secondary_container` text. 
- Radius: `full` (9999px) to contrast against the mostly rectangular UI.

### Additional Signature Components
- **The "Pulse" Indicator:** A small `primary` dot with a CSS-animated ripple, used to indicate live AI processing or "secure" status.
- **Glass-Nav:** A side navigation bar using `surface_container_low` at 80% opacity with a heavy backdrop-blur.

---

## 6. Do's and Don'ts

### Do
- **Do** use `spacing-16` or `spacing-24` between major sections to allow the design to "breathe."
- **Do** use `tertiary` (#70aaff) for informative, non-actionable data visualizations to keep the `primary` blue reserved for interaction.
- **Do** ensure all text on `primary` accents meets a 4.5:1 contrast ratio using `on_primary`.

### Don't
- **Don't** use pure white (#ffffff) for body text. Use `on_surface_variant` (#abaab1) to reduce eye strain in dark mode.
- **Don't** use standard "drop shadows." Use the Ambient Shadow specifications provided in Section 4.
- **Don't** use a border-radius larger than `lg` (0.5rem) except for Chips; we want a "precision-engineered" look, not a "friendly/bubbly" look.
- **Don't** use 100% opacity for backgrounds of floating menus; it breaks the "Sentinel Core" glass metaphor.